# Teqnovalley POS for Android (WebView app)

This Android Studio project packages the existing PHP POS website in an Android app shell. It reuses the PHP/MySQL backend; it is not a standalone/offline rewrite of the PHP system.

## Setup
1. Deploy the PHP POS folder to a web server and configure its database in `config/database.php` on the server.
2. Ensure the phone can reach that server. For a LAN-hosted POS, use the server computer's LAN IP and the correct folder path, e.g. `http://192.168.1.10/pos/`. Do not use `localhost` on the phone to refer to the server computer.
3. Open this folder in Android Studio (current stable version), allow Gradle sync, then choose **Build > Build APK(s)**. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.
4. Install the APK on the Android device. On first launch, enter the full POS website URL. Use the app menu to change the address later.

## Security and deployment notes
- Prefer HTTPS with a valid certificate for any server reachable outside a trusted private LAN. HTTP is allowed for local-network compatibility; do not expose an HTTP POS login publicly.
- The app does not embed database credentials. PHP and MySQL remain on the server.
- Authentication is handled by the existing PHP application. Use individual staff accounts and strong passwords/PINs.
- This project source is provided; an APK was not compiled in this environment because an Android SDK/Gradle build environment was not available.
