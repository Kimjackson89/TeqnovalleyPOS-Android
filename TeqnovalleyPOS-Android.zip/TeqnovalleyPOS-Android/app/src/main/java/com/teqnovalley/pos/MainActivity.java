package com.teqnovalley.pos;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "pos_settings";
    private static final String SERVER_URL = "server_url";
    private WebView webView;
    private ProgressBar progress;
    private LinearLayout root;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildLayout();
        configureWebView();
        String url = prefs.getString(SERVER_URL, "");
        if (url.isEmpty()) askForServer(null);
        else webView.loadUrl(url);
    }

    private void buildLayout() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(16), dp(6), dp(8), dp(6));
        toolbar.setBackgroundColor(Color.rgb(16, 42, 67));
        TextView brand = new TextView(this);
        brand.setText("TEQNOVALLEY  POS");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(16);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        toolbar.addView(brand, new LinearLayout.LayoutParams(0, dp(44), 1));
        Button menuButton = new Button(this);
        menuButton.setText("⋮");
        menuButton.setTextSize(24);
        menuButton.setTextColor(Color.WHITE);
        menuButton.setMinWidth(dp(44));
        menuButton.setPadding(0, 0, 0, dp(4));
        menuButton.setBackgroundColor(Color.TRANSPARENT);
        menuButton.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(MainActivity.this, menuButton);
            popup.getMenu().add("Reload POS").setOnMenuItemClickListener(item -> { webView.reload(); return true; });
            popup.getMenu().add("Change server address").setOnMenuItemClickListener(item -> { askForServer(prefs.getString(SERVER_URL, "")); return true; });
            popup.show();
        });
        toolbar.addView(menuButton, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Required by the existing POS frontend.
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                        "Cannot reach the POS server. Check the server URL and network, then reload.",
                        Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean handleUrl(String raw) {
        Uri uri = Uri.parse(raw);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if (scheme.equals("http") || scheme.equals("https")) {
            String base = prefs.getString(SERVER_URL, "");
            Uri baseUri = Uri.parse(base);
            // Keep web navigation within the configured POS host. Other web links open externally.
            if (uri.getHost() != null && uri.getHost().equalsIgnoreCase(baseUri.getHost())) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception ignored) { Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        if (scheme.equals("tel") || scheme.equals("mailto")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
            return true;
        }
        return true;
    }

    private void askForServer(String current) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://your-pos-domain.com/  or  http://192.168.1.10/pos/");
        input.setText(current == null ? prefs.getString(SERVER_URL, "") : current);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Connect to your POS")
            .setMessage("Enter the website address where your PHP POS is hosted. The server must be reachable from this phone.")
            .setView(input)
            .setCancelable(!prefs.getString(SERVER_URL, "").isEmpty())
            .setPositiveButton("Connect", null)
            .setNegativeButton(prefs.getString(SERVER_URL, "").isEmpty() ? "Exit" : "Cancel", (d, w) -> {
                if (prefs.getString(SERVER_URL, "").isEmpty()) finish();
            }).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = input.getText().toString().trim();
            Uri uri = Uri.parse(value);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
            if (!(scheme.equals("https") || scheme.equals("http")) || uri.getHost() == null) {
                input.setError("Enter a valid http:// or https:// address");
                return;
            }
            prefs.edit().putString(SERVER_URL, value).apply();
            dialog.dismiss();
            webView.loadUrl(value);
        }));
        dialog.show();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Reload POS");
        menu.add(0, 2, 1, "Change server address");
        return true;
    }
    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) { if (webView != null) webView.reload(); return true; }
        if (item.getItemId() == 2) { askForServer(prefs.getString(SERVER_URL, "")); return true; }
        return super.onOptionsItemSelected(item);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setMessage("Exit Teqnovalley POS?")
            .setNegativeButton("Stay", null).setPositiveButton("Exit", (d, w) -> finish()).show();
    }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
